using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[ExecuteInEditMode]
public class TestStage : MonoBehaviour
{
    public GameObject prefab;
    private bool display = false;

    private void OnDrawGizmos()
    {
        if (prefab == null) return;

        Gizmos.DrawIcon(transform.position, "Prefab Icon.tif");

    }

    public void Create()
    {
        display = !display;

        if (display)
        {
            Debug.Log("Create");
            prefab.GetComponent<StageCreate>().Create();
        }
        else
        {
            Debug.Log("Destroy");
            prefab.GetComponent<StageCreate>().Delete();
        }
    }

    private void Awake()
    {
        if (prefab == null) return;

        Instantiate(prefab, transform.position, transform.rotation, transform);
    }
}
