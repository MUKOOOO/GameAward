using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.Windows;
using System.IO;
#if UNITY_EDITOR
using UnityEditor;
#endif

public class EditorWindowStage : EditorWindow
{
    [MenuItem("Editor/Stage")]
    private static void Create()
    {
        // ����
        GetWindow<EditorWindowStage>("�X�e�[�W");
    }

    /// <summary>
    /// ScriptableObjectSample�̕ϐ�
    /// </summary>
    private ScriptableObjectStage stage;
    /// <summary>
    /// �A�Z�b�g�p�X
    /// </summary>
    private const string ASSET_PATH = "Assets/Resources/ScriptableObjectStage.asset";

    private void OnGUI()
    {
        if (stage == null)
        {
            stage = ScriptableObject.CreateInstance<ScriptableObjectStage>();
        }

        Color defaultColor = GUI.backgroundColor;
        using (new GUILayout.VerticalScope(EditorStyles.helpBox))
        {
            GUI.backgroundColor = Color.gray;
            using (new GUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUILayout.Label("�ݒ�");
            }
            GUI.backgroundColor = defaultColor;

            stage.SampleIntValue = EditorGUILayout.IntField("�T���v��", stage.SampleIntValue);
        }
        using (new GUILayout.VerticalScope(EditorStyles.helpBox))
        {
            GUI.backgroundColor = Color.gray;
            using (new GUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUILayout.Label("�t�@�C������");
            }
            GUI.backgroundColor = defaultColor;

            GUILayout.Label("�p�X�F" + ASSET_PATH);

            using (new GUILayout.HorizontalScope(GUI.skin.box))
            {
                GUI.backgroundColor = Color.green;
                // �ǂݍ��݃{�^��
                if (GUILayout.Button("�ǂݍ���"))
                {
                    Import();
                }
                GUI.backgroundColor = Color.magenta;
                // �������݃{�^��
                if (GUILayout.Button("��������"))
                {
                    Export();
                }
                GUI.backgroundColor = defaultColor;
            }
        }
    }
    
    private void Export()
    {
        // �ǂݍ���
        ScriptableObjectStage sample = AssetDatabase.LoadAssetAtPath<ScriptableObjectStage>(ASSET_PATH);
        if (sample == null)
        {
            sample = ScriptableObject.CreateInstance<ScriptableObjectStage>();
        }

        // �V�K�̏ꍇ�͍쐬
        if (!AssetDatabase.Contains(sample as UnityEngine.Object))
        {
            string directory = Path.GetDirectoryName(ASSET_PATH);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
            // �A�Z�b�g�쐬
            AssetDatabase.CreateAsset(sample, ASSET_PATH);
        }

        // �R�s�[
        //sample.Copy(_sample);
        EditorUtility.CopySerialized(stage, sample);

        // ���ڕҏW�ł��Ȃ��悤�ɂ���
        sample.hideFlags = HideFlags.NotEditable;
        // �X�V�ʒm
        EditorUtility.SetDirty(sample);
        // �ۑ�
        AssetDatabase.SaveAssets();
        // �G�f�B�^���ŐV�̏�Ԃɂ���
        AssetDatabase.Refresh();
    }

    private void Import()
    {
        if (stage == null)
        {
            stage = ScriptableObject.CreateInstance<ScriptableObjectStage>();
        }

        ScriptableObjectStage sample = AssetDatabase.LoadAssetAtPath<ScriptableObjectStage>(ASSET_PATH);
        if (sample == null)
            return;

        // �R�s�[����
        //_sample.Copy(sample);
        EditorUtility.CopySerialized(sample, stage);
    }

    // Start is called before the first frame update
    void Start()
    {
        // �ǂݍ��� & �����i�t�@�C������ASSET_PATH�Œ�`�������́j
        stage = ScriptableObject.Instantiate(Resources.Load<ScriptableObjectStage>("ScriptableObjectStage"));
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
