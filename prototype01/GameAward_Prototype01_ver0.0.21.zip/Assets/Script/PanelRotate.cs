using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelRotate : MonoBehaviour, IEventCaller
{
    public string myname;
    int PanelFlg;

    //�p�l����]�t���O
    bool rot = true;
    //Player.cs�ɉ�]�����ǂ����n��
    public static bool prot = true;
    //�p�l����]�X�s�[�h
    public float speed = 0.0f;
    float speedX;
    float speedZ;

    public GameObject uppanel;
    public GameObject downpanel;
    public GameObject rightpanel;
    public GameObject leftpanel;


    public static PanelRotate instance;

    //�p�l���̐F�ύX
    public Material lightmaterial;
    public Material originalmaterial;

    private GameObject uplight;
    private GameObject downlight;
    private GameObject rightlight;
    private GameObject leftlight;

    public GameObject p;

    // Start is called before the first frame update
    void Start()
    {
        p = GameObject.Find("Player");

        PanelFlg = 0;
        if (instance == null)
        {
            instance = this;
        }

        GameObject[] panel = GameObject.FindGameObjectsWithTag("Panel");

        foreach (GameObject obj in panel)
        {
            if (gameObject.transform.position.x + 2 == obj.transform.position.x &&
                gameObject.transform.position.z == obj.transform.position.z)
            {
                rightpanel = obj;
            }
            else if (gameObject.transform.position.x - 2 == obj.transform.position.x &&
                gameObject.transform.position.z == obj.transform.position.z)
            {
                leftpanel = obj;
            }
            else if (gameObject.transform.position.z + 2 == obj.transform.position.z &&
                gameObject.transform.position.x == obj.transform.position.x)
            {
                uppanel = obj;
            }
            else if (gameObject.transform.position.z - 2 == obj.transform.position.z &&
                gameObject.transform.position.x == obj.transform.position.x)
            {
                downpanel = obj;
            }
        }

        if (uppanel != null)
        {
            uplight = uppanel.transform.Find("panel").gameObject;
        }
        if (downpanel != null)
        {
            downlight = downpanel.transform.Find("panel").gameObject;
        }
        if (rightpanel != null)
        {
            rightlight = rightpanel.transform.Find("panel").gameObject;
        }
        if (leftpanel != null)
        {
            leftlight = leftpanel.transform.Find("panel").gameObject;
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        //�p�l������]������Ȃ���Ή�]
        if (rot == true && PanelFlg == 1)
        {
            prot = false;
            rot = false;
            PanelFlg = 0;
            StartCoroutine(rt());
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        //�p�l���̏�Ƀv���C���[������Ă���̂ł����
        if (collision.gameObject.tag == "Player")
        {
            //�F�𖾂邭
            ColorChange_Light();
        }
    }

    void OnCollisionExit(Collision collision)
    {
        //���̐F��
        if (collision.gameObject.tag == "Player")
        {
            ColorChange_Original();

        }

    }

    public virtual void SetRotate()
    {
        if (gameObject.tag == "Panel" || gameObject.tag == "Line")
        {
            if (uppanel != null)
            {
                //uplight.GetComponent<Renderer>().material = editmaterial;

                uppanel.GetComponent<PanelRotate>().SetUpPanelFlag();
            }
            if (downpanel != null)
            {
                //downlight.GetComponent<Renderer>().material = editmaterial;
                downpanel.GetComponent<PanelRotate>().SetDownPanelFlag();
            }
            if (rightpanel != null)
            {
                //rightlight.GetComponent<Renderer>().material = editmaterial;
                rightpanel.GetComponent<PanelRotate>().SetRightPanelFlag();
            }
            if (leftpanel != null)
            {
                //leftlight.GetComponent<Renderer>().material = editmaterial;
                leftpanel.GetComponent<PanelRotate>().SetLeftPanelFlag();
            }
        }
    }

    public void SetPanelFlag()
    {
        PanelFlg = 1;
    }
    public void SetUpPanelFlag()
    {
        PanelFlg = 1;
        speedX = 10.0f;
        speedZ = 0.0f;
    }
    public void SetDownPanelFlag()
    {
        PanelFlg = 1;
        speedX = -10.0f;
        speedZ = 0.0f;
    }
    public void SetRightPanelFlag()
    {
        PanelFlg = 1;
        speedX = 0.0f;
        speedZ = -10.0f;
    }
    public void SetLeftPanelFlag()
    {
        PanelFlg = 1;
        speedX = 0.0f;
        speedZ = 10.0f;
    }

    public IEnumerator SetUpChainPanelFlag(float time)
    {
        PanelFlg = 1;
        speedX = 10.0f;
        speedZ = 0.0f;
        if (uppanel != null)
        {
            yield return new WaitForSeconds(time);
            uppanel.GetComponent<PanelRotate>().StartCoroutine(uppanel.GetComponent<PanelRotate>().SetUpChainPanelFlag(time));
        }
    }
    public IEnumerator SetDownChainPanelFlag(float time)
    {
        PanelFlg = 1;
        speedX = -10.0f;
        speedZ = 0.0f;
        if (downpanel != null)
        {
            yield return new WaitForSeconds(time);
            downpanel.GetComponent<PanelRotate>().StartCoroutine(downpanel.GetComponent<PanelRotate>().SetDownChainPanelFlag(time));
        }
    }
    public IEnumerator SetRightChainPanelFlag(float time)
    {
        PanelFlg = 1;
        speedX = 0.0f;
        speedZ = -10.0f;
        if (rightpanel != null)
        {
            yield return new WaitForSeconds(time);
            rightpanel.GetComponent<PanelRotate>().StartCoroutine(rightpanel.GetComponent<PanelRotate>().SetRightChainPanelFlag(time));
        }
    }
    public IEnumerator SetLeftChainPanelFlag(float time)
    {
        PanelFlg = 1;
        speedX = 0.0f;
        speedZ = 10.0f;
        if (leftpanel != null)
        {
            yield return new WaitForSeconds(time);
            leftpanel.GetComponent<PanelRotate>().StartCoroutine(leftpanel.GetComponent<PanelRotate>().SetLeftChainPanelFlag(time));
        }
    }

    public void SetUpPanel(GameObject obj)
    {
        uppanel = obj;
    }

    public void SetDownPanel(GameObject obj)
    {
        downpanel = obj;
    }

    public void SetRightPanel(GameObject obj)
    {
        rightpanel = obj;
    }

    public void SetLeftPanel(GameObject obj)
    {
        leftpanel = obj;
    }

    //�p�l����]����
    IEnumerator rt()
    {
        //�ꎞ�I�Ƀv���C���[��Script�𖳌��ɂ���
        //p.GetComponent<Player>().enabled = false;

        p.GetComponent<Player>().StartCoroutine(p.GetComponent<Player>().SetMoveFlag(false));

        int i = 0;
        if (speedZ == 0)
        {
            while (i < 18)
            {
                i++;
                this.transform.Rotate(speedX, 0, 0, Space.World);
                yield return null;
            }
        }
        else if (speedX == 0)
        {
            while (i < 18)
            {
                i++;
                this.transform.Rotate(0, 0, speedZ, Space.World);
                yield return null;
            }
        }
        rot = true;
        prot = true;

        //�v���C���[��Script��L���ɂ���
        Invoke("StartP", 0.7f);
    }

    public void EventCall()
    {
        // ���O��\�����܂��B
        //Debug.Log("EventSystems�ɂ��C�x���g���ʒm���ꂽ�I");
        Debug.Log("PanelRotate");
        SetRotate();
    }

    public void ColorChange_Light()
    {
        //�p�l���̐F�𖾂邭����
        if (uppanel != null)
        {
            uplight.GetComponent<Renderer>().material = lightmaterial;
        }

        if (downpanel != null)
        {
            downlight.GetComponent<Renderer>().material = lightmaterial;
        }

        if (rightpanel != null)
        {
            rightlight.GetComponent<Renderer>().material = lightmaterial;
        }

        if (leftpanel != null)
        {
            leftlight.GetComponent<Renderer>().material = lightmaterial;
        }
    }

    public void ColorChange_Original()
    {
        //���̐F�ɖ߂�
        if (uppanel != null)
        {
            uplight.GetComponent<Renderer>().material = originalmaterial;
        }
        if (downpanel != null)
        {
            downlight.GetComponent<Renderer>().material = originalmaterial;
        }
        if (rightpanel != null)
        {
            rightlight.GetComponent<Renderer>().material = originalmaterial;

        }
        if (leftpanel != null)
        {
            leftlight.GetComponent<Renderer>().material = originalmaterial;

        }

    }

    void StartP()
    {
        p.GetComponent<Player>().enabled = true;
    }
}
