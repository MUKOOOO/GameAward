using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Scroll : MonoBehaviour
{
    bool StartFlg;

    // Start is called before the first frame update
    void Start()
    {
        StartFlg = false;
    }

    // Update is called once per frame
    void Update()
    {
        // transform���擾
        Transform myTransform = this.transform;

        // ���W���擾
        Vector3 pos = myTransform.position;
        

        if (pos.z <= 18.5 && StartFlg == true)
        {
            pos.z += 0.006f;    // z���W��0.01���Z

            myTransform.position = pos;  // ���W��ݒ�
        }

        if(Input.GetKeyDown(KeyCode.A))
        {
            StartFlg = true;
        }
    }
}
