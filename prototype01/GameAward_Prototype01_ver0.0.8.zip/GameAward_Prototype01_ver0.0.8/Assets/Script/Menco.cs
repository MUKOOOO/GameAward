using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Menco : MonoBehaviour
{

    void NotifyEvent(GameObject targetObj)
    {
        ExecuteEvents.Execute<IEventCaller>(
                        target: targetObj,
                        eventData: null,
                        functor: CallMyEvent
                        );
    }

    void CallMyEvent(IEventCaller inf, BaseEventData eventData)
    {
        inf.EventCall();
    }

     void Start()
    {
        Rigidbody rigidbody = gameObject.GetComponent<Rigidbody>();
        rigidbody.AddForce(0, -1000, 0);
        //rigidbody.AddForce(0, -100, 0, ForceMode.Impulse);
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Panel")
        {
            NotifyEvent(collision.gameObject);
            Destroy(gameObject, 0.0f);
        }
    }
}
