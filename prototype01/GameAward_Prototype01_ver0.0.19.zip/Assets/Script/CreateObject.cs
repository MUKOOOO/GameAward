using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;

public class CreateObject : MonoBehaviour
{
    [Header("�g���v���n�u"), SerializeField]
    public GameObject[] obj;

    [Header("�w�肷��|�W�V�����ꗗ"),SerializeField]
    public TextAsset[] text;

    [Header("�|�W�V�����ő�w�萔"),SerializeField]
    public int maxPos;

    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < obj.Length; i++) 
        {
            Create(i);
        }
    }

    private void Create(int index)
    {
        string posData = text[index].text;
        Vector3[] pos = new Vector3[maxPos];
        int idx = 0;
        //string[] letter = new string[3];
        int letterIndex = 0;

        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        StringBuilder sb3 = new StringBuilder();

        foreach (char c in posData)
        {
            if (c == '/') 
            {
                pos[idx] = new Vector3(float.Parse(sb1.ToString()), float.Parse(sb2.ToString()), float.Parse(sb3.ToString()));
                Debug.Log(idx + "�Ԗ�" + " x : " + sb1.ToString() + " y : " + sb2.ToString() + " z : " + sb3.ToString());
                idx++;
                sb1 = null;
                sb2 = null;
                sb3 = null;
                sb1 = new StringBuilder();
                sb2 = new StringBuilder();
                sb3 = new StringBuilder();
                letterIndex = 0;
            }
            else if (c == ',')
            {
                letterIndex++;
            }
            else
            {
                //letter[letterIndex] = letter[letterIndex] + c;
                if (letterIndex == 0)
                {
                    sb1.Append(c);
                    Debug.Log(sb1.ToString());
                }
                else if (letterIndex == 1)
                {
                    sb2.Append(c);
                    Debug.Log(sb2.ToString());
                }
                else if (letterIndex == 2) 
                {
                    sb3.Append(c);
                    Debug.Log(sb3.ToString());
                }
            }
        }

        int rand = Random.Range(0, maxPos);

        Debug.Log(rand + "�Ԗ� " + " x : " + pos[rand].x + " y : " + pos[rand].y + " z : " + pos[rand].z);

        GameObject instance = Instantiate(obj[index], pos[rand], Quaternion.identity);
    }
}
