using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //�v���C���[�̈ړ����x
    [SerializeField]
    private float speed = 5.0f;

    //��]����p�l�����̎擾
    public GameObject Panel;

    //�����R�I�u�W�F�N�g��ݒ�
    [SerializeField]
    private GameObject Menco;

    //�����R�̐����|�W�V����
    private Vector3 MencoPos;

    public GameObject mainCamera = null;

    //z���𒲐��B���̐��Ȃ�v���C���[�̑O�ɁA���̐��Ȃ�v���C���[�̌��ɔz�u����
    public int zAdjustY = 5;
    public int zAdjustZ = -5;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (mainCamera != null)
        {
            mainCamera.transform.position = new Vector3(transform.position.x, transform.position.y + zAdjustY, transform.position.z + zAdjustZ);
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            MencoPos = transform.position;
            MencoPos.y = 1.0f;
            if (transform.localEulerAngles.y == 0.0f)
            {
                MencoPos.z += 1.5f;
            }
            else if(transform.localEulerAngles.y == 90.0f)
            {
                MencoPos.x += 1.5f;
            }
            else if (transform.localEulerAngles.y == 180.0f)
            {
                MencoPos.z -= 1.5f;
            }
            else if (transform.localEulerAngles.y == 270.0f)
            {
                MencoPos.x -= 1.5f;
            }
            GameObject ball = (GameObject)Instantiate(Menco, MencoPos, Quaternion.identity);
        }

        //�v���C���[�ړ��֐�
        Operation();
    }

    //�v���C���[�ړ��֐�
    void Operation()
    {
        if (Input.GetKey(KeyCode.UpArrow))
            transform.position += transform.up * speed * Time.deltaTime;

        if (Input.GetKey(KeyCode.DownArrow))
            transform.position -= transform.up * speed * Time.deltaTime;

        if (Input.GetKey(KeyCode.D))
        {
            transform.rotation = Quaternion.Euler(0.0f, 90.0f, 0.0f);
            transform.position += transform.forward * speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.rotation = Quaternion.Euler(0.0f, 270.0f, 0.0f);
            transform.position += transform.forward * speed * Time.deltaTime;

        }
        if (Input.GetKey(KeyCode.W))
        {
            transform.rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);
            transform.position += transform.forward * speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.rotation = Quaternion.Euler(0.0f, 180.0f, 0.0f);
            transform.position += transform.forward * speed * Time.deltaTime;
        }
    }
}