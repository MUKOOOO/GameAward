using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Menco : MonoBehaviour
{
    // Start is called before the first frame update

    private PanelRotate rotate;
    private GameObject[] panel = GameObject.FindGameObjectsWithTag("Panel");
    public float radius;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnCollisionEnter(Collision collision)
    {

        GameObject obj = collision.gameObject;
        rotate = obj.GetComponent<PanelRotate>();
        rotate.SetPanelFlag();

        Debug.Log("Hit");

        //if (collision.gameObject.tag == "Panel")
        //{
        //    for(int i = 0; i < panel.Length; i++)
        //    {
        //        rotate = panel[i].GetComponent<PanelRotate>();
        //        if (transform.position.x + radius >= panel[i].transform.position.x &&
        //            transform.position.x <= panel[i].transform.position.x)
        //        {
        //            rotate.SetPanelFlag();
        //        }
        //        else if (transform.position.x - radius <= panel[i].transform.position.x &&
        //            transform.position.x >= panel[i].transform.position.x)
        //        {
        //            rotate.SetPanelFlag();
        //        }
        //        else if (transform.position.z - radius <= panel[i].transform.position.z &&
        //            transform.position.z >= panel[i].transform.position.z)
        //        {
        //            rotate.SetPanelFlag();
        //        }
        //        else if (transform.position.z + radius >= panel[i].transform.position.z &&
        //            transform.position.z <= panel[i].transform.position.z)
        //        {
        //            rotate.SetPanelFlag();
        //        }
        //    }

        //}
    }
}
