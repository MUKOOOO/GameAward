using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageCreate : MonoBehaviour
{
    public TextAsset textAsset;

    //�z�u����I�u�W�F�N�g
    [Header("�g���p�l���v���n�u"), SerializeField]
    public GameObject[] panel;
    public GameObject player;

    [Header("���_"), SerializeField]
    public Vector3 createPos;

    [Header("�p�l���̕�"), SerializeField]
    public Vector3 spaceScale;

    void Start()
    {
        CreateStage(createPos);

        createPos = Vector3.zero;

        Destroy(gameObject);
    }

    void CreateStage(Vector3 pos)
    {

        Vector3 originPos = pos;
        string stageTextData = textAsset.text;

        foreach (char c in stageTextData)
        {

            GameObject obj = null;

            if (c == '1')
            {
                obj = Instantiate(panel[0], pos, Quaternion.identity) as GameObject;
                obj.name = panel[0].name;
                //pos.x += obj.transform.lossyScale.x;
                pos.x += spaceScale.x;
            }
            else if (c == '2')
            {
                obj = Instantiate(panel[1], pos, Quaternion.identity) as GameObject;
                obj.name = panel[1].name;
                pos.x += spaceScale.x;
            }
            else if (c == '3')
            {
                obj = Instantiate(panel[2], pos, Quaternion.identity) as GameObject;
                obj.name = panel[2].name;
                pos.x += spaceScale.x;
            }
            else if (c == '4')
            {
                obj = Instantiate(panel[3], pos, Quaternion.identity) as GameObject;
                obj.name = panel[3].name;
                pos.x += spaceScale.x;
            }
            else if (c == '5')
            {
                obj = Instantiate(panel[4], pos, Quaternion.identity) as GameObject;
                obj.name = panel[4].name;
                pos.x += spaceScale.x;
            }
            else if (c == '6')
            {
                obj = Instantiate(panel[5], pos, Quaternion.identity) as GameObject;
                obj.name = panel[5].name;
                pos.x += spaceScale.x;
            }
            else if (c == '7')
            {
                obj = Instantiate(panel[6], pos, Quaternion.identity) as GameObject;
                obj.name = panel[6].name;
                pos.x += spaceScale.x;
            }

            else if (c == 'p')
            {
                obj = Instantiate(player, pos, Quaternion.identity) as GameObject;
                obj.name = player.name;
                pos.x += obj.transform.lossyScale.x;
            }
            else if (c == '\n')
            {
                pos.z += spaceScale.z;
                //pos.x = originPos.x;
                pos.x = 0.0f;
            }
            else if (c == ' ')
            {
                pos.x += spaceScale.x;
            }
        }
    }
}
