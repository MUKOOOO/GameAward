using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class CameraController : MonoBehaviour
{
    [SerializeField]
    [Tooltip("�Ǐ]���������^�[�Q�b�g")]
    private GameObject target;

    private Vector3 offset;
    private bool move = false;
    public int rot;
    public float rotspeed;

    // Start is called before the first frame update
    void Start()
    {
        transform.position = new Vector3(target.transform.position.x, target.transform.position.y + 5.0f, target.transform.position.z - 5.0f);
        offset = gameObject.transform.position - target.transform.position;

        Vector3 rot = transform.localEulerAngles;
        rot.x = 50.0f;
        transform.localEulerAngles = rot;

    }
    
    /// <summary>
    /// �v���C���[���ړ�������ɃJ�������ړ�����悤�ɂ��邽�߂�LateUpdate�ɂ���B
    /// </summary>
    void LateUpdate()
    {
        // �J�����̈ʒu���^�[�Q�b�g�̈ʒu�ɃI�t�Z�b�g�𑫂����ꏊ�ɂ���B
        gameObject.transform.position = target.transform.position + offset;
    }

    public void CameraMove(InputAction.CallbackContext context)
    {
        if (!context.performed) return;
        move = false;
        StartCoroutine(rt());
        Vector3 pos = transform.position;
        pos.y -= 10.0f;
        rotspeed *= -1;
    }

    IEnumerator rt()
    {
        int i = 0;

        while (i < rot)
        {
            i++;
            this.transform.Rotate(rotspeed, 0, 0, Space.World);
            yield return null;
        }
    }

    IEnumerator Move()
    {
        int i = 0;
        while (i < rot)
        {
            i++;
            transform.position = new Vector3(0.0f, -0.1f, 0.0f);
            yield return null;
        }
        move = true;
    }

    public bool GetCameraMoveFlag()
    {
        return move;
    }
}
