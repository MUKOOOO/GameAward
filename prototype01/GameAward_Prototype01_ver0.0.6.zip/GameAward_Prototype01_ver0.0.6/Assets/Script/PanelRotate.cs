using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelRotate : MonoBehaviour, IEventCaller
{
    public string myname;
    int PanelFlg;

    //�p�l����]�t���O
    bool rot = true;
    //Player.cs�ɉ�]�����ǂ����n��
    public static bool prot = true;
    //�p�l����]�X�s�[�h
    public float speed = 0.0f;
    float speedX;
    float speedZ;

    public GameObject uppanel;
    public GameObject downpanel;
    public GameObject rightpanel;
    public GameObject leftpanel;

    public static PanelRotate instance;

    // Start is called before the first frame update
    void Start()
    {
        PanelFlg = 0;
        if (instance == null)
        {
            instance = this;
        }
    }

    // Update is called once per frame
    void Update()
    {
        //�p�l������]������Ȃ���Ή�]
        if (rot == true && PanelFlg == 1)
        {
            prot = false;
            rot = false;
            PanelFlg = 0;
            StartCoroutine(rt());
        }
    }

    public void SetRotate()
    {
        if (uppanel != null)
        {
            uppanel.GetComponent<PanelRotate>().SetUpPanelFlag();
        }
        if (downpanel != null)
        {
            downpanel.GetComponent<PanelRotate>().SetDownPanelFlag();
        }
        if (rightpanel != null)
        {
            rightpanel.GetComponent<PanelRotate>().SetRightPanelFlag();
        }
        if (leftpanel != null)
        {
            leftpanel.GetComponent<PanelRotate>().SetLeftPanelFlag();
        }
    }

    public void SetPanelFlag()
    {
        PanelFlg = 1;
    }
    public void SetUpPanelFlag()
    {
        PanelFlg = 1;
        speedX = 10.0f;
        speedZ = 0.0f;
    }
    public void SetDownPanelFlag()
    {
        PanelFlg = 1;
        speedX = -10.0f;
        speedZ = 0.0f;
    }
    public void SetRightPanelFlag()
    {
        PanelFlg = 1;
        speedX = 0.0f;
        speedZ = -10.0f;
    }
    public void SetLeftPanelFlag()
    {
        PanelFlg = 1;
        speedX = 0.0f;
        speedZ = 10.0f;
    }

    //�p�l����]����
    IEnumerator rt()
    {
        int i = 0;
        if (speedZ == 0)
        {
            while (i < 18)
            {
                i++;
                this.transform.Rotate(speedX, 0, 0);
                yield return null;
            }
        }
        else if (speedX == 0)
        {
            while (i < 18)
            {
                i++;
                this.transform.Rotate(0, 0, speedZ);
                yield return null;
            }
        }
        rot = true;
        prot = true;
    }

    public void EventCall()
    {
        // ���O��\�����܂��B
        //Debug.Log("EventSystems�ɂ��C�x���g���ʒm���ꂽ�I");
        Debug.Log("PanelRotate");
        SetRotate();
    }
}
