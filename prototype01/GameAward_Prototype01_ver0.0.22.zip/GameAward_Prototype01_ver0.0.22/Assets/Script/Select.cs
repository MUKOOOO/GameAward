using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Select : MonoBehaviour
{
    //���X�g
    [SerializeField] List<SceneObject> scenes = new List<SceneObject>();

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //if(Input.GetKeyDown(KeyCode.Alpha1))
        //{
        //    SceneManager.LoadScene("laser_1");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha2))
        //{
        //    SceneManager.LoadScene("2x2");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha3))
        //{
        //    SceneManager.LoadScene("figure_heart");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha4))
        //{
        //    SceneManager.LoadScene("kotei");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha5))
        //{
        //    SceneManager.LoadScene("line");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha6))
        //{
        //    SceneManager.LoadScene("scroll");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha7))
        //{
        //    SceneManager.LoadScene("zigzag");
        //}
    }

    public void NextScene()
    {
        SceneManager.LoadScene(scenes[0]);
    }
}
