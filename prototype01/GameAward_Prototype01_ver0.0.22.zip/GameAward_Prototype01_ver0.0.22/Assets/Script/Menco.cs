using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Menco : MonoBehaviour
{
    private bool key = false;

    void NotifyEvent(GameObject targetObj)
    {
        ExecuteEvents.Execute<IEventCaller>(
                        target: targetObj,
                        eventData: null,
                        functor: CallMyEvent
                        );
    }

    void CallMyEvent(IEventCaller inf, BaseEventData eventData)
    {
        inf.EventCall();
    }

     void Start()
    {
        Rigidbody rigidbody = gameObject.GetComponent<Rigidbody>();
        rigidbody.AddForce(0, -1000, 0);
        //rigidbody.AddForce(0, -100, 0, ForceMode.Impulse);
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SetKeyFlag(bool flag)
    {
        key = flag;
        if(key)
        {
            Debug.Log("������");
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Panel" || collision.gameObject.tag == "Line") 
        {
            NotifyEvent(collision.gameObject);
            //collision.gameObject.GetComponent<PanelRotate>().SetRotate();
            Destroy(gameObject, 0.0f);

            Debug.Log("�Փ˔���");
        }
        else if (key)
        {
            //NotifyEvent(collision.gameObject);
            collision.gameObject.GetComponent<KeyPanel>().SetKeyPanelRotate();
            Destroy(gameObject, 0.0f);
        }
    }
}
