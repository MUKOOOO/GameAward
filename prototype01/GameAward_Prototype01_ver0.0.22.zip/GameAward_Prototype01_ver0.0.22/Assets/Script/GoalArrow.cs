using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalArrow : MonoBehaviour
{
    public float nowPosi;

    // Start is called before the first frame update
    void Start()
    {
        nowPosi = this.transform.position.y;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void FixedUpdate()
    {
        this.transform.Rotate(0, 4f, 0);

        transform.position = new Vector3(transform.position.x, nowPosi + Mathf.PingPong(Time.time/2, 0.5f), transform.position.z);
    }
}
