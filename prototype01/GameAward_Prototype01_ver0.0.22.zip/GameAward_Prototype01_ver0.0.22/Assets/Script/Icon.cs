using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Icon : MonoBehaviour
{
    private Vector2 vec;

    [Header("�X�s�[�h����"), SerializeField]
    public float speed;

    private GameObject[] select;

    // Start is called before the first frame update
    void Start()
    {
        select = GameObject.FindGameObjectsWithTag("Select");
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += new Vector3(vec.x, vec.y, 0.0f);

        Vector3 pos = transform.position;

        if (transform.position.x <= -3.95) pos.x = -3.95f;
        else if (transform.position.x >= 3.95f) pos.x = 3.95f;

        if (transform.position.y >= 2.65f) pos.y = 2.65f;
        else if (transform.position.y <= -0.65f) pos.y = -0.65f;

        transform.position = pos;
    }

    public void Move(InputAction.CallbackContext context)
    {
        vec = Vector2.zero;
        if (!context.performed) return;

        vec = context.ReadValue<Vector2>();

        vec /= speed;
    }

    public void PushSelectPanel(InputAction.CallbackContext context)
    {
        if (!context.performed) return;

        foreach(GameObject obj in select)
        {
            if (obj.GetComponent<Selection>().NowSelect())
            {
                obj.GetComponent<Selection>().NextSceneChange();
            }
        }
    }
}
