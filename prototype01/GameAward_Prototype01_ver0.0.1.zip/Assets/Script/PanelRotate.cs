using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelRotate : MonoBehaviour
{
    public string myname;
    int PanelFlg;

    // Start is called before the first frame update
    void Start()
    {
        PanelFlg = 0;

    }

    // Update is called once per frame
    void Update()
    {
        //if (Input.GetMouseButtonDown(0))
        //{
        //    // �X�N���[���ʒu����3D�I�u�W�F�N�g�ɑ΂���Ray�i�����j�𔭎�
        //    Ray rayOrigin = Camera.main.ScreenPointToRay(Input.mousePosition);

        //    // Ray���I�u�W�F�N�g�Ƀq�b�g�����ꍇ
        //    if (Physics.Raycast(rayOrigin, out RaycastHit hitInfo))
        //    {
        //        // �^�O��Player�̏ꍇ�i����if�����폜����ƁA�S�ẴQ�[���I�u�W�F�N�g�ɑ΂��鏈���ɂȂ�܂��j
        //        if (hitInfo.collider.CompareTag("Untagged"))
        //        {
        //            // �����_���ȐF�ɕύX����ꍇ
        //            hitInfo.collider.GetComponent<MeshRenderer>().material.color =
        //                new Color(Random.value, Random.value, Random.value);
        //            if (PanelFlg == 0)
        //                PanelFlg = 1;

        //            if (PanelFlg == 2)
        //                PanelFlg = 3;

        //            Debug.Log("��]");
        //        }
        //    }
        //}        

        if (PanelFlg == 1)
        {
            transform.Rotate(Vector3.right, 180 * Time.deltaTime);

            Debug.Log(transform.localEulerAngles.x);

            if (transform.localEulerAngles.x >= 180)
            {
                PanelFlg = 2;
            }

        }

        if (PanelFlg == 3)
        {
            transform.Rotate(Vector3.right, 180 * Time.deltaTime);

            Debug.Log(transform.localEulerAngles.x);

            if (transform.localEulerAngles.x >= 358)
            {
                PanelFlg = 0;
            }

        }
    }

    public void SetPanelFlag()
    {
        if (PanelFlg == 0)
            PanelFlg = 1;

        if (PanelFlg == 2)
            PanelFlg = 3;
    }
}
