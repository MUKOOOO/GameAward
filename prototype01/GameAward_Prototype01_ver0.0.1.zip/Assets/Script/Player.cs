/*===============================================================================
                                                    �쐬�Җ��@���R���o
                                                    �X�V���@�@02��04��
=================================================================================
�v���C���[�̈ړ��y�уp�l���̉�]
=================================================================================*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //�v���C���[�̈ړ����x
    [SerializeField]
    private float speed = 5.0f;

    //��]����p�l�����̎擾
    public GameObject Panel;

    //int PanelFlg;

    // Start is called before the first frame update
    void Start()
    {
        //Vector3 rot = Panel.transform.localEulerAngles;
        //PanelFlg = 0;
    }

    // Update is called once per frame
    void Update()
    {
        //��]�̏�Ԃ�ύX
        //if (Input.GetKeyDown(KeyCode.Space))
        //{
        //    if (PanelFlg == 0)
        //        PanelFlg = 1;

        //    if (PanelFlg == 2)
        //        PanelFlg = 3;
        //}

        //if (PanelFlg == 1)
        //{
        //    Panel.transform.Rotate(Vector3.right, 180 * Time.deltaTime);

        //    Debug.Log(Panel.transform.localEulerAngles.x);

        //    if (Panel.transform.localEulerAngles.x >= 180)
        //    {
        //        PanelFlg = 2;
        //    }
            
        //}

        //if (PanelFlg == 3)
        //{
        //    Panel.transform.Rotate(Vector3.right, 180 * Time.deltaTime);

        //    Debug.Log(Panel.transform.localEulerAngles.x);

        //    if (Panel.transform.localEulerAngles.x >= 358)
        //    {
        //        PanelFlg = 0;
        //    }

        //}

        //�v���C���[�ړ��֐�
        Operation();
    }

    //�v���C���[�ړ��֐�
    void Operation()
    {
        if (Input.GetKey(KeyCode.UpArrow))
            transform.position += transform.up * speed * Time.deltaTime;

        if (Input.GetKey(KeyCode.DownArrow))
            transform.position -= transform.up * speed * Time.deltaTime;

        if (Input.GetKey(KeyCode.D))
            transform.position += transform.right * speed * Time.deltaTime;

        if (Input.GetKey(KeyCode.A))
            transform.position -= transform.right * speed * Time.deltaTime;

        if (Input.GetKey(KeyCode.W))
            transform.position += transform.forward * speed * Time.deltaTime;

        if (Input.GetKey(KeyCode.S))
            transform.position -= transform.forward * speed * Time.deltaTime;
    }
}
