//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class LaserTurret: MonoBehaviour
//{


//    // Start is called before the first frame update
//    void Start()
//    {
//    }

//    // Update is called once per frame
//    void Update()
//    {
        
//    }

//    void OnRay()
//    {

//        float lazerDistance = 10f;
//        Vector3 direction = hand.transform.forward * lazerDistance;
//        Vector3 pos = hand.transform.position;

//        RaycastHit hit;
//        Ray ray = new Ray(pos, hand.transform.forward);
//        lineRenderer.SetPosition(0, hand.transform.position);

//        if (Physics.Raycast(ray, out hit, lazerDistance))
//        {
//            lineRenderer.SetPosition(1, pos + direction);
//        }

//        Debug.DrawRay(ray.origin, pos + direction, Color.red, 0.1f);
//    }
//}
