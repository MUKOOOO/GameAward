using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class CameraRotate : MonoBehaviour
{   
    public GameObject target;
    private Vector3 offset;

    Vector2 rot;
    public float rotspeed;

    void Start()
    {
        transform.position = new Vector3(target.transform.position.x, target.transform.position.y + 5.0f, target.transform.position.z - 5.0f);
        offset = gameObject.transform.position - target.transform.position;

        Vector3 rot = transform.localEulerAngles;
        rot.x = 50.0f;
        transform.localEulerAngles = rot;
    }

    void Update()
    {
        Vector3 move = target.GetComponent<Player>().GetMove();

        transform.position += new Vector3(move.x, 0.0f, move.z);

        transform.RotateAround(target.transform.position, Vector3.up, rot.x * rotspeed);
        transform.RotateAround(target.transform.position, Vector3.right, rot.y * rotspeed);
    }

    public void Rotate(InputAction.CallbackContext context)
    {
        rot = context.ReadValue<Vector2>();
        //Debug.Log("x : " + rot.x + " y : " + rot.y);
    }

    public void Reset(InputAction.CallbackContext context)
    {
        if (!context.performed) return;
        transform.position = new Vector3(target.transform.position.x, target.transform.position.y + 5.0f, target.transform.position.z - 5.0f);

        transform.localEulerAngles = new Vector3(50.0f, 0.0f, 0.0f);
    }
}
