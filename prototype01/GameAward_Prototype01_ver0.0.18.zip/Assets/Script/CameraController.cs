using System.Collections;
using System.Collections.Generic;
using System.Xml.Serialization;
using UnityEngine;
using UnityEngine.InputSystem;

//public class Zoom : MonoBehaviour
//{
//    protected int scaling;

//    public virtual Zoom ZoomOutIn(Camera camera, int speed)
//    {
//        return null;        
//    }

//    public IEnumerator zoom(Camera camera, int scaling, int speed)
//    {
//        while (scaling != camera.fieldOfView)
//        {
//            scaling += speed;
//            yield return null;
//        }
//    }
//}

//public class ZoomLow : Zoom
//{
//    private void Awake()
//    {
//        scaling = 10;
//    }

//    public override Zoom ZoomOutIn(Camera camera, int speed)
//    {
//        StartCoroutine(base.zoom(camera, scaling, speed));

//        return new ZoomMiddle();
//    }
//}

//public class ZoomMiddle : Zoom
//{
//    private void Awake()
//    {
//        scaling = 60;
//    }

//    public override Zoom ZoomOutIn(Camera camera, int speed)
//    {
//        bool flag = false;

//        if (camera.fieldOfView < scaling)
//        {
//            flag = true;
//        }
//        else
//        {
//            speed *= (-1);
//        }

//        StartCoroutine(zoom(camera, scaling, speed));        

//        if (flag)
//        {
//            return new ZoomHeight();
//        }

//        return new ZoomLow();
//    }
//}

//public class ZoomHeight : Zoom
//{
//    private void Awake()
//    {
//        scaling = 90;
//    }

//    public override Zoom ZoomOutIn(Camera camera, int speed)
//    {
//        StartCoroutine(base.zoom(camera, scaling, -speed));

//        return new ZoomMiddle();
//    }
//}

public class CameraController : MonoBehaviour
{
    [SerializeField]
    [Tooltip("�Ǐ]���������^�[�Q�b�g")]
    public GameObject target;
    private Vector3 offset;

    Vector2 rot;
    public float rotspeed;

    private Camera cam;
    private float zoom;
    private float view;
    private int state = 0;
    private bool zoomflag = false;
    private bool zoomout = true;

    [Header("�g��k���̃T�C�Y"), SerializeField]
    public int[] scaling;

    [Header("�Y�[���X�s�[�h"), SerializeField]
    public float speed;

    //private Zoom zoom = new ZoomMiddle();

    void Start()
    {
        transform.position = new Vector3(target.transform.position.x, target.transform.position.y + 5.0f, target.transform.position.z - 5.0f);
        offset = gameObject.transform.position - target.transform.position;

        Vector3 rot = transform.localEulerAngles;
        rot.x = 50.0f;
        transform.localEulerAngles = rot;

        cam = GetComponent<Camera>();
        view = cam.fieldOfView;
    }

    void Update()
    {
        Vector3 move = target.GetComponent<Player>().GetMove();

        transform.position += new Vector3(move.x, 0.0f, move.z);

        transform.RotateAround(target.transform.position, Vector3.up, rot.x * rotspeed);
        transform.RotateAround(target.transform.position, Vector3.right, rot.y * rotspeed);

        cam.fieldOfView = view + zoom;

        if (zoomflag)
        {
            //Debug.Log("Zoom");
                switch (state)
                {
                case 0:
                    if (cam.fieldOfView >= scaling[state + 1])
                    {
                        cam.fieldOfView = scaling[state++];
                        zoomflag = false;
                        zoomout = true;
                        Debug.Log("Middle");
                    }
                    break;

                case 1:
                    if (zoomout)
                    {
                        if (cam.fieldOfView >= scaling[state + 1])
                        {
                            cam.fieldOfView = scaling[state++];
                            zoomflag = false;
                            zoomout = false;
                            Debug.Log("Height");
                        }
                    }
                    else
                    {
                        if (cam.fieldOfView <= scaling[state - 1])
                        {
                            cam.fieldOfView = scaling[state--];
                            zoomflag = false;
                            zoomout = true;
                            Debug.Log("Low");
                        }
                    }
                    break;

                case 2:
                    if (cam.fieldOfView <= scaling[state - 1])
                    {
                        cam.fieldOfView = scaling[state--];
                        zoomflag = false;
                        Debug.Log("Middle");
                    }
                    break;
            }
        }
    }

    public void Rotate(InputAction.CallbackContext context)
    {
        rot = context.ReadValue<Vector2>();
        //Debug.Log("x : " + rot.x + " y : " + rot.y);
    }

    public void Reset(InputAction.CallbackContext context)
    {
        if (!context.performed) return;
        transform.position = new Vector3(target.transform.position.x, target.transform.position.y + 5.0f, target.transform.position.z - 5.0f);

        transform.localEulerAngles = new Vector3(50.0f, 0.0f, 0.0f);
    }

    public void Zoom(InputAction.CallbackContext context)
    {
        if(!context.performed) return;

        if (!zoomflag)
        {
            StartCoroutine(Zoom());
        }
    }

    IEnumerator Zoom()
    {
        int count = 0;

        if (zoomout)
        {
            while (count < 3)
            {
                zoom += speed;
                count++;
                yield return null;
            }
            Debug.Log("�Y�[���A�E�g");
        }
        else
        {
            while (count < 3)
            {
                zoom -= speed;
                count++;
                yield return null;
            }
            Debug.Log("�Y�[���C��");
        }

        zoomflag = true;
        Debug.Log("�Y�[���I��");
    }


    //public void CameraMove(InputAction.CallbackContext context)
    //{
    //    if (!context.performed) return;
    //    move = false;
    //    StartCoroutine(rt());
    //    Vector3 pos = transform.position;
    //    pos.y -= 10.0f;
    //    rotspeed *= -1;
    //}

    //IEnumerator rt()
    //{
    //    int i = 0;

    //    while (i < rot)
    //    {
    //        i++;
    //        this.transform.Rotate(rotspeed, 0, 0, Space.World);
    //        yield return null;
    //    }
    //}

    //IEnumerator Move()
    //{
    //    int i = 0;
    //    while (i < rot)
    //    {
    //        i++;
    //        transform.position = new Vector3(0.0f, -0.1f, 0.0f);
    //        yield return null;
    //    }
    //    move = true;
    //}

    //public bool GetCameraMoveFlag()
    //{
    //    return move;
    //}
}
